-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: northwind
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `list`
--

DROP TABLE IF EXISTS `list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `list` (
  `idlist` int NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(45) DEFAULT NULL,
  `UnitPrice` float DEFAULT NULL,
  `SupplierName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idlist`)
) ENGINE=InnoDB AUTO_INCREMENT=636 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list`
--

LOCK TABLES `list` WRITE;
/*!40000 ALTER TABLE `list` DISABLE KEYS */;
INSERT INTO `list` VALUES (509,'Chai',18,'Exotic Liquids'),(510,'Chang',19,'Exotic Liquids'),(511,'Aniseed Syrup',10,'Exotic Liquids'),(512,'Chef Anton\'s Cajun Seasoning',22,'New Orleans Cajun Delights'),(513,'Chef Anton\'s Gumbo Mix',21.35,'New Orleans Cajun Delights'),(514,'Grandma\'s Boysenberry Spread',25,'Grandma Kelly\'s Homestead'),(515,'Uncle Bob\'s Organic Dried Pears',30,'Grandma Kelly\'s Homestead'),(516,'Northwoods Cranberry Sauce',40,'Grandma Kelly\'s Homestead'),(517,'Mishi Kobe Niku',97,'Tokyo Traders'),(518,'Ikura',31,'Tokyo Traders'),(519,'Queso Cabrales',21,'Cooperativa de Quesos \'Las Cabras\''),(520,'Queso Manchego La Pastora',38,'Cooperativa de Quesos \'Las Cabras\''),(521,'Konbu',6,'Mayumi\'s'),(522,'Tofu',23.25,'Mayumi\'s'),(523,'Genen Shouyu',15.5,'Mayumi\'s'),(524,'Pavlova',17.45,'Pavlova, Ltd.'),(525,'Alice Mutton',39,'Pavlova, Ltd.'),(526,'Carnarvon Tigers',62.5,'Pavlova, Ltd.'),(527,'Teatime Chocolate Biscuits',9.2,'Specialty Biscuits, Ltd.'),(528,'Sir Rodney\'s Marmalade',81,'Specialty Biscuits, Ltd.'),(529,'Sir Rodney\'s Scones',10,'Specialty Biscuits, Ltd.'),(530,'Gustaf\'s Knäckebröd',21,'PB Knäckebröd AB'),(531,'Tunnbröd',9,'PB Knäckebröd AB'),(532,'Guaraná Fantástica',4.5,'Refrescos Americanas LTDA'),(533,'NuNuCa Nuß-Nougat-Creme',14,'Heli Süßwaren GmbH & Co. KG'),(534,'Gumbär Gummibärchen',31.23,'Heli Süßwaren GmbH & Co. KG'),(535,'Schoggi Schokolade',43.9,'Heli Süßwaren GmbH & Co. KG'),(536,'Rössle Sauerkraut',45.6,'Plutzer Lebensmittelgroßmärkte AG'),(537,'Thüringer Rostbratwurst',123.79,'Plutzer Lebensmittelgroßmärkte AG'),(538,'Nord-Ost Matjeshering',25.89,'Nord-Ost-Fisch Handelsgesellschaft mbH'),(539,'Gorgonzola Telino',12.5,'Formaggi Fortini s.r.l.'),(540,'Mascarpone Fabioli',32,'Formaggi Fortini s.r.l.'),(541,'Geitost',2.5,'Norske Meierier'),(542,'Sasquatch Ale',14,'Bigfoot Breweries'),(543,'Steeleye Stout',18,'Bigfoot Breweries'),(544,'Inlagd Sill',19,'Svensk Sjöföda AB'),(545,'Gravad lax',26,'Svensk Sjöföda AB'),(546,'Côte de Blaye',263.5,'Aux joyeux ecclésiastiques'),(547,'Chartreuse verte',18,'Aux joyeux ecclésiastiques'),(548,'Boston Crab Meat',18.4,'New England Seafood Cannery'),(549,'Jack\'s New England Clam Chowder',9.65,'New England Seafood Cannery'),(550,'Singaporean Hokkien Fried Mee',14,'Leka Trading'),(551,'Ipoh Coffee',46,'Leka Trading'),(552,'Gula Malacca',19.45,'Leka Trading'),(553,'Røgede sild',9.5,'Lyngbysild'),(554,'Spegesild',12,'Lyngbysild'),(555,'Zaanse koeken',9.5,'Zaanse Snoepfabriek'),(556,'Chocolade',12.75,'Zaanse Snoepfabriek'),(557,'Maxilaku',20,'Karkki Oy'),(558,'Valkoinen suklaa',16.25,'Karkki Oy'),(559,'Manjimup Dried Apples',53,'G\'day, Mate'),(560,'Filo Mix',7,'G\'day, Mate'),(561,'Perth Pasties',32.8,'G\'day, Mate'),(562,'Tourtière',7.45,'Ma Maison'),(563,'Pâté chinois',24,'Ma Maison'),(564,'Gnocchi di nonna Alice',38,'Pasta Buttini s.r.l.'),(565,'Ravioli Angelo',19.5,'Pasta Buttini s.r.l.'),(566,'Escargots de Bourgogne',13.25,'Escargots Nouveaux'),(567,'Raclette Courdavault',55,'Gai pâturage'),(568,'Camembert Pierrot',34,'Gai pâturage'),(569,'Sirop d\'érable',28.5,'Forêts d\'érables'),(570,'Tarte au sucre',49.3,'Forêts d\'érables'),(571,'Vegie-spread',43.9,'Pavlova, Ltd.'),(572,'Wimmers gute Semmelknödel',33.25,'Plutzer Lebensmittelgroßmärkte AG'),(573,'Louisiana Fiery Hot Pepper Sauce',21.05,'New Orleans Cajun Delights'),(574,'Louisiana Hot Spiced Okra',17,'New Orleans Cajun Delights'),(575,'Laughing Lumberjack Lager',14,'Bigfoot Breweries'),(576,'Scottish Longbreads',12.5,'Specialty Biscuits, Ltd.'),(577,'Gudbrandsdalsost',36,'Norske Meierier'),(578,'Outback Lager',15,'Pavlova, Ltd.'),(579,'Fløtemysost',21.5,'Norske Meierier'),(580,'Mozzarella di Giovanni',34.8,'Formaggi Fortini s.r.l.'),(581,'Röd Kaviar',15,'Svensk Sjöföda AB'),(582,'Longlife Tofu',10,'Tokyo Traders'),(583,'Rhönbräu Klosterbier',7.75,'Plutzer Lebensmittelgroßmärkte AG'),(584,'Lakkalikööri',18,'Karkki Oy'),(585,'Original Frankfurter grüne Soße',13,'Plutzer Lebensmittelgroßmärkte AG');
/*!40000 ALTER TABLE `list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-11 15:47:11
